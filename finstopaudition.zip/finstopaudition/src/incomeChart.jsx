import * as React from 'react';
import Paper from '@material-ui/core/Paper';
import {
  Chart,
  BarSeries,
  Title,
  ArgumentAxis,
  ValueAxis,
} from '@devexpress/dx-react-chart-material-ui';

import { Animation } from '@devexpress/dx-react-chart';

const data = [
  { month: 'Jan', Income: 4 },
  { month: 'Feb', Income: 7 },
  { month: 'Mar', Income: 6},
  { month: 'Apr', Income: 2 },
  { month: 'May', Income: 7 },
  { month: 'Jun', Income: 6},
  { month: 'Jul', Income:5},
  { month: 'Aug', Income: 6 },
  { month: 'Sep', Income: 5 },
  { month: 'Oct', Income: 6 },
  { month: 'Nov', Income:5 },
  { month: 'Dec', Income: 7},
];

export default class Demo extends React.PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      data,
    };
  }

  render() {
    const { data: chartData } = this.state;

    return (

      <div className = "chart">
     
      <Paper className="paper">
      
      <Chart className="dataChat"
        data={chartData}
      >
        <ArgumentAxis />
        <ValueAxis max={7} />

        <BarSeries
          valueField="Income"
          argumentField="month"
        />
       
        <Title text="Income   Expenses" />
        <Animation />
      </Chart>
    </Paper></div>
      
    );
  }
}