import React from "react";
import {Container} from 'react-bootstrap';
import {Row} from 'react-bootstrap';
import {Col} from 'react-bootstrap';
import {IoMdFlower} from 'react-icons/io'
import {ProgressBar} from 'react-bootstrap';

function Reputation(){
    return(

        <div className="reputationCont">
            <Container>
  <Row>
    <Col xs={1}><span style = {{color:"orange", paddingRight:"none", fontSize:"30px"}}><IoMdFlower/></span></Col>
    <Col >
    <table className="reputTable">
    <tr>
    <td >
    <h6>Star</h6>
  </td>
  <td><span style={{marginLeft:"-80px", fontWeight:"none", color:"black", textDecoration:"none"}}>85%</span></td>
    
  </tr>

  <tr>
  <td>
  <ProgressBar variant="warning" now={85}  style={{width:"200px",height:"3px"}}/>
  </td>
 
  </tr>
</table>
    </Col>
  </Row>
  </Container>
        </div>
    );}

    export default Reputation