import React from "react";
import {FaShoppingBag} from 'react-icons/fa'
import {faUsers} from '@fortawesome/free-solid-svg-icons'

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {Card} from 'react-bootstrap';
import {Container} from 'react-bootstrap';
import {Row} from 'react-bootstrap';
import {Col} from 'react-bootstrap';

function ProductAndFollowersCard(){
    return(
        <div className="prodFollowCard">
    <Container>
  <Row>
  <Col style ={{width:"50%"}}><span>
    <table>
  <tr>
    <td><span style={{padding:"2px", marginRight: "10px"}}><FaShoppingBag/> </span></td>
    <td>218</td>
    
  </tr>

  <tr>
    <td></td>
    <td className="desc" style={{fontSize:"12px",marginRight: "10px"}}>Products</td>
  </tr>
    </table>
    </span><div className="vl ln"/></Col>
   
    <Col style ={{width:"50%"}}>
    
    <span>
    <table>
  <tr>
    <td><span style={{padding:"3px",margin:"5px"}}><FontAwesomeIcon icon={faUsers} /> </span></td>
    <td>2580</td>
    
  </tr>

  <tr>
    <td></td>
    <td className="desc" style={{fontSize:"12px"}}>Followers</td>
  </tr>
    </table>
    </span>

    </Col>
  </Row>
  </Container>
  </div>


    );
}

    export default ProductAndFollowersCard