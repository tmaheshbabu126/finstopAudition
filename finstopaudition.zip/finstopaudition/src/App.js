
import './App.css';
import {Container} from 'react-bootstrap';
import {Row} from 'react-bootstrap';
import {Col} from 'react-bootstrap';
import './index.css';


import 'bootstrap/dist/css/bootstrap.min.css';
import Sidebar from "./Sidebar"
import MainBar from "./mainBar"
import RightSideBar from "./rightSideBar"



function App() {
  return (
    <div className = "containerBox">
    <Container>
      <Row>
      <Col xs={1}><Sidebar /> <div className="vl"/> </Col>
        
      <Col xs={9}><MainBar/><div className="vl"></div></Col>
        
      <Col xs={2}><RightSideBar/></Col>
        
      </Row>
      </Container>
      </div>
  );
}

export default App;
