import React from "react";

import {FaShoppingBag} from 'react-icons/fa'
import {Card} from 'react-bootstrap';

function OverviewCards(props) {
    return (
<Card className="overviewcard">
<span  style={{color: props.iconColor}}>{props.icon}<span style={{
    
    float:"right", color : props.percentageColor

}}>{props.percentage}</span></span>

<h5 style={{marginTop: "10px"}}>{props.value}</h5>
<p className = "desc">{props.desc}</p>

</Card>

    );}


    export default OverviewCards