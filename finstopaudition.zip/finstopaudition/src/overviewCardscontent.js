import {FaShoppingBag} from 'react-icons/fa'
import {FaShoppingCart} from 'react-icons/fa'
import {AiFillPieChart} from 'react-icons/ai'

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {faUsers} from '@fortawesome/free-solid-svg-icons'
var overview =[
    {
        id : 1,
        icon : <FaShoppingBag/>,
        iconColor :"orange",
        percentage : "+24%",
        percentageColor : "green",
        value : "$27,340.00",
        desc : "Total sales"
    },
    {
        id : 2,
        icon : <AiFillPieChart/>,
        iconColor :"purple",
        percentage : "-32%",
        percentageColor : "red",
        value : "$27,340.00",
        desc : "Total sales"
    },
    {
        id : 3,
        icon :  <FontAwesomeIcon icon={faUsers} />,
        iconColor :"green",
        percentage : "+48%",
        percentageColor : "green",
        value : "$18,260.00",
        desc : "Total visitors"
    },
    {
        id : 4,
        icon : <FaShoppingCart/>,
        iconColor :"red",
        percentage : "-12%",
        percentageColor : "red",
        value : "$11,340.00",
        desc : "Total orders"
    }
]


export default overview