import React from "react";
import OverviewCards from "./overviewCards"
import SearchBar from "./searchBar"
import {FaShoppingBag} from 'react-icons/fa'
import {Card} from 'react-bootstrap';
import OverviewContent from "./overviewCardscontent"
import IncomeChart from "./incomeChart"
import PopularProducts from "./popularProducts"
function createCard(overview){
    return(
        <OverviewCards  
        key = {overview.id}
        icon = {overview.icon}
        iconColor ={overview.iconColor}
        percentage ={overview.percentage}
        percentageColor = {overview.percentageColor}
        value = {overview.value}
        desc ={overview.desc}

        />
    );
}



function MainBar() {
    return (
        <div className="mainBar">
             <SearchBar/>

             <h5 className="header">Overview</h5>

             <div>{OverviewContent.map(createCard)}</div>

             <br/>
            <div>  <IncomeChart/></div>
        <PopularProducts/>

        </div>
   

    )};


    export default MainBar

