import React from "react";
import {Card} from 'react-bootstrap';
import {Table} from 'react-bootstrap'
import {FaShoppingCart } from 'react-icons/fa'
function PopularProducts(props) {
    return (

        <Card style={{marginTop: "20px", padding:"20px", border : "2px solid rgb(248, 242, 242) ;"}}>
            <h5>Popular Products</h5>

            <Table  hover>
  <thead style = {{backgroundColor :"rgb(236, 232, 232)", border:"none", outline:"none"}}>
    <tr >
      <th>Product</th>
      <th>Name</th>
      <th>Date</th>
      <th>Category</th>
      <th>Brand</th>
      <th>Price</th>
      <th>Status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td> <FaShoppingCart className="iconOrange"/></td>
      <td><tr>Hat</tr>
      <tr><p className="productCode">#2807856940</p></tr></td>
      <td>August 12,2020</td>
      <td>Fashion</td>
      <td>Fashion</td>
      <td style={{color:"green"}}>$99.89</td>
      <td><tr>Available</tr>
      <tr><p className="productCode">18k viewers</p></tr></td>
    </tr>
    <tr>
      <td> <FaShoppingCart className="iconOrange"/></td>
      <td><tr>Smartphone</tr>
      <tr><p className="productCode">#3456756940</p></tr></td>
      <td>August 12,2020</td>
      <td>Gadget</td>
      <td>Fashion</td>
      <td style={{color:"green"}}>$99.89</td>
      <td><tr>Available</tr>
      <tr><p className="productCode" >18k viewers</p></tr></td>
    </tr>
   
  </tbody>
</Table>
        </Card>

    );}

    export default PopularProducts