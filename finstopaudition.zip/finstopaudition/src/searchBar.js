import React from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {faSearch} from '@fortawesome/free-solid-svg-icons'


function searchBar() {
    return (
       

            <div class="input-icons"> 
            <i class="fa fa-user icon" type="submit" > <FontAwesomeIcon icon={faSearch} />
            

            </i>
            <input class="input-field" type="text" placeholder=" Search for products" name="search"/> 
            </div>

    )};


    export default searchBar