import React from "react";
import brand from "./brand.PNG"
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faThLarge} from '@fortawesome/free-solid-svg-icons'
import { FaBook } from 'react-icons/fa';
import {FaShoppingBag} from 'react-icons/fa'
import { faCog} from '@fortawesome/free-solid-svg-icons'
import {faLocationArrow} from '@fortawesome/free-solid-svg-icons'
import {faUsers} from '@fortawesome/free-solid-svg-icons'




function Sidebar() {
    return (
    <div className="sideBar">
        <img src={brand} alt="Logo" className ="logo menu" />
        <h6 className="menu">Menu</h6>
        <p className="menuContents">
        <a  href="#">
        <span >
         <FontAwesomeIcon icon={faThLarge} /></span> 
         &nbsp; Overview</a></p>

        
         <p className="menuContents ">
         <a  href="#" >
         <span> <FaBook /></span> &nbsp; Orders </a>
         </p>

         <p className="menuContents "><a  href="#" ><span> 
         <FaShoppingBag/></span>  &nbsp; Products</a> </p>

         <p className="menuContents "><a  href="#" ><span> 
         <FontAwesomeIcon icon={faCog} /></span>&nbsp; Settings </a></p>



         <h6 className="menu">Buisiness</h6>

         <p className="menuContents ">
         <a  href="#" ><span>
         <FontAwesomeIcon icon={faLocationArrow} /></span> &nbsp; Settings
         </a>
         </p>

         <p className="menuContents ">
         <a  href="#" >
         <span>
         <FontAwesomeIcon icon={faUsers} /></span> &nbsp; Followers
         </a>
         </p>



            <h6 className="menuContents menu copyright">©2020</h6>
            <p className="menuContents copycontent">Platform for solution solution</p>
            <p className="menuContents copycontent">Platform for solution</p>

       
  </div>
        
        );
  };
  
  export default Sidebar