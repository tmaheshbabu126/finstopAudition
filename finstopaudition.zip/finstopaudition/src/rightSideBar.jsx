import React from "react";
import {HiBell} from "react-icons/hi"
import {FaPen} from "react-icons/fa"
import RightBrand from "./rightbrand.PNG"
import ProductAndFollowersCard from "./productAndFollowersCard"
import Reputation from "./reputation";
import RecentOrders from "./recentOrders";
function RightSideBar(){
    return(
        <div className = "cont">
     
        <a href ="#" style={{color:"black"}}><span className="rightIcons"><HiBell/></span></a>
        <a href ="#" style={{color:"black"}}>
        <span className="rightIcons" style={{float:"right", margin:"-20px"}}><FaPen /></span></a>
        <div className="rightLogo">
        <img src={RightBrand} alt="Logo" />
        </div>
        <br/>
        <ProductAndFollowersCard/>
        <br/>
        <div className="cont2">
        <h5>
            Reputation
        </h5>

        <Reputation />
        <br/>
        <h5>Recent Orders <span style={{float : "right",}}> <a href="#" style={{ color:"#00008B"}}>See all </a></span></h5>
        </div>
        
           <RecentOrders/>
            
        </div>

    )};

export default RightSideBar