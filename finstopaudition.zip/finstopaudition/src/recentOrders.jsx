import React from "react";
import {Container} from 'react-bootstrap';
import {Row} from 'react-bootstrap';
import {Col} from 'react-bootstrap';
import {FaShoppingCart} from 'react-icons/fa'
import {Table} from 'react-bootstrap'

function RecentOrders(){
    return(
<div className ="RecentOrders">
<Table>
<tbody>
    <tr>
      <td> <FaShoppingCart className="iconOrange"/></td>
      <td><tr>Rmi</tr>
      <tr><p className="productCode">2 min ago</p></tr></td>
     
      <td style={{color:"green"}}>+$80.00</td>
      
    </tr>
    <tr>
      <td> <FaShoppingCart className="iconOrange"/></td>
      <td><tr>E1-421</tr>
      <tr><p className="productCode">2 min ago</p></tr></td>
     
      <td style={{color:"green"}}>+$80.00</td>
      
    </tr>

    <tr>
      <td> <FaShoppingCart className="iconOrange"/></td>
      <td><tr>N D3500</tr>
      <tr><p className="productCode">2 min ago</p></tr></td>
     
      <td style={{color:"green"}}>+$80.00</td>
      
    </tr>
   
  </tbody>
</Table>
</div>
    );}

    export default RecentOrders